#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNIVERSIDAD AUTÓNOMA DEL ESTADO DE MÉXICO
CU UAEM ZUMPANGO

UA: Algoritmos Geneticos
Profesor: Asdrubal Lopez Chau
    
Alumnos: Camacho Sandoval Brandon Ali
         Rojas Palacios Luis Martin
         Sanchez Alanis Jose Antonio   

Tema: Proyecto. Ejercicio 4: Algoritmo de Agrupamiento
Descripción: Clase Seleccion

@author: anton
Created on Mon Mar 28 11:50:30 2022
"""

import numpy as np
import random

class Seleccion:
    
    def selecciona(self, aptitudes, k=2):       # Metodo para seleccionar k individuos
       
        probabilidades = [np.exp(aptitud)/np.sum(np.exp(aptitudes))for aptitud in aptitudes] # Calcula la probabilidad de                       
                                                                                             # cada individuo para ser                                                                                            
                                                                                             # elegido
        indices = list(range(len(aptitudes)))                                                # Guarda los indices de los
                                                                                             # individuos 
        return random.choices(indices, probabilidades, k=k)                                  # Escoge a k individuos de la
                                                                                             # lista y guarda sus indices
        
        











