# -*- coding: utf-8 -*-
"""
UNIVERSIDAD AUTÓNOMA DEL ESTADO DE MÉXICO
CU UAEM ZUMPANGO

UA: Algoritmos Geneticos
Profesor: Asdrubal Lopez Chau
    
Alumnos: Camacho Sandoval Brandon Ali
         Rojas Palacios Luis Martin
         Sanchez Alanis Jose Antonio   

Tema: Proyecto. Ejercicio 4: Algoritmo de Agrupamiento
Descripción: Clase Centroide

Created on Sat May 21 19:48:55 2022

@author: Luis Martin R.P
"""

import numpy as np

class Centroide:
    
    def __init__(self, k=2, datos=[[0,0],[0,0]]):   # Constructor de Centroide
        self.k = k                                  # Definimos el numero de grupos
        self.datos = datos                          # Definimos los datos (puntos)
    
    def calculaCentroide(self, ind):                # Metodo para calcular los Centroides
        centroides = []                             # Definimos el arreglo centroides
        aux = ind.genes.copy()                      # Definimos un aux para manejar mejor los genes del ind
        for i in range (self.k):                    # Ciclo doble con el que calculamos el centroide de cada 
            centro = [0.0,0.0]                      # grupo. Para ello definimos el arreglo centro y un contador
            cont = 0.0                              # que se inicializaran en (0,0) y 0 respectivamente cada 
            for gen in aux:                         # que se busque el centroide del siguiente grupo, en el siguiente
                if (gen.gen[2] == i):               # ciclo se van sumando los valores de 'x' y 'y' de los puntos de
                    centro[0] += gen.gen[0]         # su respectivo grupo en la variable centro, tambien se van 
                    centro[1] += gen.gen[1]         # contabilizando los puntos que son sumados al aumentar el contador
                    cont += 1.0                     # en 1, cuando se pasado todos los puntos de un grupo, se divide
            if cont == 0:                           # la suma obtenida en 'x' y 'y' entre el contador 
                cont = 1                            # ( (Suma de x's/cont, Suma de y's/cont) ), ya que hemos obtenido
            centro[0] = centro[0]/cont              # el centroide de un grupo, lo pasamos al arreglo de centroides
            centro[1] = centro[1]/cont              # para despues regresar dicho arreglo con los centroides de 
            centroides.append(centro)               # cada grupo
        return centroides        
            
    def acomodargrupos(self, ind, centroides):      # Metodo para acomodar los puntos a su centroide mas cercano
        aux = ind.genes.copy()                      # Definimos un aux para manejar mejor los genes del ind
        grupoDist = []                              # Definimos el arreglo grupoDist
        dist = 0                                    # Definimos la variable dist
        
        for dato in self.datos:                     # Ciclo en donde se llena el arreglo distancias con las distancias
            distancias = []                         # Euclidianas de cada punto de los datos con un centroide, despues 
            for i in range (self.k):                # dicho arreglo es guardado en el arreglo grupoDist, y se repite el
                dist = np.sqrt((dato[0]-centroides[i][0])**2 + (dato[1]-centroides[i][1])**2)
                distancias.append(dist)             # ciclo con los otros centriodes a modo de crear una matriz de 
            grupoDist.append(distancias)            # distancias, donde las columnas son las distancias de todos los
                                                    # puntos respecto a un centroide y las filas son las distancias  
                                                    # de un punto respecto a todos los centroides
        
        for i in range (len(self.datos)):           # Ciclo en donde se acomodan los puntos al grupo al que pertencen,
            idxMayor = np.argmin(grupoDist[i])      # para esto se toma la matriz de distancias (gruposDist), y se revisa
            aux[i].gen[2] = idxMayor                # por cada punto cual es el centroide mas cercano a este. Una vez 
                                                    # identidicado el centroide y por lo tanto el grupo, se actualiza
                                                    # el grupo asignado al punto por el grupo del centroide mas
                                                    # cercano
    