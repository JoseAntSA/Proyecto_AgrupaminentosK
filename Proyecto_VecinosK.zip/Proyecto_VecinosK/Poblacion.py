#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNIVERSIDAD AUTÓNOMA DEL ESTADO DE MÉXICO
CU UAEM ZUMPANGO

UA: Algoritmos Geneticos
Profesor: Asdrubal Lopez Chau
    
Alumnos: Camacho Sandoval Brandon Ali
         Rojas Palacios Luis Martin
         Sanchez Alanis Jose Antonio   

Tema: Proyecto. Ejercicio 4: Algoritmo de Agrupamiento
Descripción: Clase Poblacion

@author: anton
Created on Mon Mar 28 11:28:34 2022
"""

from CromosomaReal import CromosomaReal as CR

class Poblacion:
    
    def __init__(self, k=2, datos=[[0,0],[0,0]], size=100):       # Constructor de Poblacion
        self.k = k                                                # Definimos el numero de grupos
        self.datos = datos.copy()                                 # Definimos los datos (puntos)
        self.size = size                                          # Definimos el tamaño de poblacion
        
    def init(self):                             # Metodo para inicializar la poblacion
        poblacion = []# Arreglo vacio           # Definimos el arreglo poblacion
        for i in range(self.size):              # Ciclo para crear individuos para el arreglo poblacion    
            ind = CR(self.k, self.datos)        # de acuerdo al tamaño de la poblacion, los inicializamos
            ind.init()                          # y despues los agregamos el arreglo poblacion
            poblacion.append(ind)
        
        self.poblacion = poblacion              # Guardamos la poblacion
        
    def __str__(self):                          # Metodo para pasar a cadena la poblacion
        cad = ""                                # Creamos un cadena vacia
        for ind in self.poblacion:              # Ciclo para pasar a la cadena cada cromosoma 
            cad = cad + ind.__str__() + "\n"    # (individuo) que conforma la poblacion
        return cad                              # Retornamos la cadena