# -*- coding: utf-8 -*-
"""
UNIVERSIDAD AUTÓNOMA DEL ESTADO DE MÉXICO
CU UAEM ZUMPANGO

UA: Algoritmos Geneticos
Profesor: Asdrubal Lopez Chau
    
Alumnos: Camacho Sandoval Brandon Ali
         Rojas Palacios Luis Martin
         Sanchez Alanis Jose Antonio   

Tema: Proyecto. Ejercicio 4: Algoritmo de Agrupamiento
Descripción: Archivo Test

@author: anton
Created on Sat May 28 14:34:45 2022
"""

from AlgoritmoEvolutivo import AlgoritmoEvolutivo as AE
import pandas as pd
import numpy as np

puntos = pd.read_csv("Datos2.csv")                      # Cargamos los datos del archivo CSV
datos = np.array(puntos).tolist()                       # Convertimos en una lista los datos que cargamos

k = int(input("Ingresa el No. de grupos deseado: "))    # Pedimos al usuario el numero de grupos

ae = AE(k, datos, 100)                                  # Creo un objeto de tipo AlgoritmoEvolutivo
ae.init()                                               # Inicializo el AlgoritmoEvolutivo

print("Se ha inicializado la poblacion.")
print("Realizando evoluciones...")
for i in range(100):                                    # Ciclo para realizar las evoluciones
    ae.evolucion()                                      # Evoluciono la poblacion a la siguiente generacion

print("\nGeneracion final...")
print("------------------------------")
ae.showPob(True)                                        # Muestro la poblacion final con sus aptitudes 
ae.GraficarMejor()                                      # Grafico los grupos obtenidos
