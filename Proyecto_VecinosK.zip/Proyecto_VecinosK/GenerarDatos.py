# -*- coding: utf-8 -*-
"""
UNIVERSIDAD AUTÓNOMA DEL ESTADO DE MÉXICO
CU UAEM ZUMPANGO

UA: Algoritmos Geneticos
Profesor: Asdrubal Lopez Chau
    
Alumnos: Camacho Sandoval Brandon Ali
         Rojas Palacios Luis Martin
         Sanchez Alanis Jose Antonio   

Tema: Proyecto. Ejercicio 4: Algoritmo de Agrupamiento
Descripción: Programa para generar un archivo CSV con datos de puntos (x,y)

@author: anton
Created on Wed May 25 15:25:04 2022
"""

import pandas as pd
import random

x, y = [], []                               # Definimos los arreglos 'x' y 'y'

for i in range (100):                       # Ciclo para llenar los arreglos 'x' y 'y' con datos
    aleatorio = random.uniform(0.0, 15.0)   # con punto decimal (5.6, 4.5, etc). Cada dato es
    redondeado = round(aleatorio, 1)        # creado de forma aleatoria
    x.append(redondeado)                    
                                            
    aleatorio = random.uniform(0.0, 15.0)   
    redondeado = round(aleatorio, 1)        
    y.append(redondeado)                    

data = {'x': x,                             # Definmos data que contendra las etiquetas 'x' y 'y' y los arreglos
        'y': y,                             # que llenamos anteriomente con los datos. Esta data representa un
        }                                   # conjunto de puntos.

df = pd.DataFrame(data, columns = ['x', 'y'])   # Definimos el dataFrame
df.to_csv('Datos2.csv', index=False)            # Convertimos el dataFrame en un archivo de tipo CSV, sin indices.