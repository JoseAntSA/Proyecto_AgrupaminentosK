# -*- coding: utf-8 -*-
"""
UNIVERSIDAD AUTÓNOMA DEL ESTADO DE MÉXICO
CU UAEM ZUMPANGO

UA: Algoritmos Geneticos
Profesor: Asdrubal Lopez Chau
    
Alumnos: Camacho Sandoval Brandon Ali
         Rojas Palacios Luis Martin
         Sanchez Alanis Jose Antonio   

Tema: Proyecto. Ejercicio 4: Algoritmo de Agrupamiento
Descripción: Clase CromosomaReal

@author: anton
Created on Mon Apr 28 13:27:39 2022
"""

from GenReal import GenReal as GR
import random
import numpy as np

class CromosomaReal:
    
    def __init__(self, k=2, datos=[[0,0],[0,0]]):       # Constructor de CromosomaReal
        self.datos = datos.copy()                       # Definimos los datos (puntos)
        self.k = k                                      # Definimos el numero de grupos
        self.grupos = self.gruposAleatorios()           # Definimos el arreglo de grupos aleatorios
        self.genes = []                                 # Definimos el arreglo de genes del cromosoma
        
        for i in range( len(self.datos)):               # Ciclo para pasar a cada gen del cromosoma el grupo
            gen = GR( self.grupos[i], self.datos[i] )   # al que pertenecera, este grupo es sacado del arreglo
            self.genes.append(gen)                      # grupos, el gen es almacendado en el arreglo genes
          
            
    def init(self):                     # Metodo para inicializar el CromosomaReal
        for gen in self.genes:          # Ciclo para inicializar cada gen del
           gen.initGen()                # cromosoma
    
    def gruposAleatorios(self):         # Metodo para definir el arreglo de grupos aleatorios
        grupos = []                     # Definimos el arreglo grupos
        for i in range ( self.k ):      # Ciclo para llenar el arreglo grupos
            grupos.append(i)            # llendo desde 0 a k (0, 1, 2, ..., k)
            
        gruposK = []                    # Definimos el arreglo gruposL    
        cont = 0                        # Definimos un contador
        
        for i in range ( int(np.ceil(len(self.datos)/self.k)) ):    # Ciclo para llenar el arreglo gruposk, se usa el    
            gruposAle = random.sample(grupos, self.k)               # metodo random.sample para obtener una arreglo
            for grupo in gruposAle:                                 # desordenado de grupos ([1, 2, 3] -> [2, 3, 1]).
                gruposK.append(grupo)                               # y pasarlo al arreglo gruposk.
                cont += 1                                           # Como hay n datos y k debe ser menor o igual a n 
                if(cont == len(self.datos)):                        # entonces se repite el ciclo hasta que el contador
                   return gruposK                                   # sea igual al numero de datos (n), es decir hasta
                                                                    # el numero de elementos de gruposk sea igual a n
               
    def cruza(self, genesMadre):                        # Metodo para realizar la cruza en dos cromosomas
        padre = self.genes.copy()                       # Definimos los genes del cromosoma padre
        madre = genesMadre.genes.copy()                 # Definimos los genes del cromosoma madre
        
        tam = int( np.ceil((len(self.datos) - 1)/2.) )  # Calcula la mitad de la longitud del cromosoma
        
        genesH1 = padre[0:tam]                          # Le pasamos al hijo 1 la primera mitad del padre
        genesH1.extend(madre[tam:])                     # Le pasamos al hijo 1 la segunda mitad de la madre 
        
        genesH2 = madre[0:tam]                          # Le pasamos al hijo 2 la primera mitad de la madre
        genesH2.extend(padre[tam:])                     # Le pasamos al hijo 2 la segunda mitad del padre

        
        hijo1 = CromosomaReal(self.k, self.datos)       # Creamos el GenReal del Hijo 1
        hijo2 = CromosomaReal(self.k, self.datos)       # Creamos el GenReal del Hijo 2
        
        hijo1.genes = genesH1                           # Le pasamos los genes correspodientes al hijo1
        hijo2.genes = genesH2                           # Le pasamos los genes correspodientes al hijo2
        
        for i in range ( len(self.datos) ):             # Ciclo para actualizar el arreglo grupos de los hijos
            hijo1.grupos[i] = hijo1.genes[i].gen[2]     # de acuerdo a los genes que se obtuvieron al momento
            hijo2.grupos[i] = hijo2.genes[i].gen[2]     # de la cruza entre la madre y el padre
            
        return [hijo1, hijo2]                           # Retornamos los hijos
        
    def mutar(self):                                    # Metodo para mutar un cromosoma
        self.grupos = self.gruposAleatorios()           # Cambiamos el arreglo grupos del cromosoma
        for i in range ( len(self.datos) ):             # Ciclo para cambiar el grupo de cada gen del cromosoma
            self.genes[i].gen[2] = self.grupos[i]       # de acuerdo a los nuevos elementos del arreglo grupos
    
    def __str__(self):                          # Metodo para imprimir el CromosomaReal
        cad = ""                                # Creamos un cadena vacia
        for gen in self.genes:                  # Ciclo para pasar a la cadena cada gen
            cad = cad + gen.__str__()           # del cromosoma
        return cad                              # Retornamos la cadena