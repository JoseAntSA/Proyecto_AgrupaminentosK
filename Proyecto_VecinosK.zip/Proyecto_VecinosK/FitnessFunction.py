# -*- coding: utf-8 -*-
"""
UNIVERSIDAD AUTÓNOMA DEL ESTADO DE MÉXICO
CU UAEM ZUMPANGO

UA: Algoritmos Geneticos
Profesor: Asdrubal Lopez Chau
    
Alumnos: Camacho Sandoval Brandon Ali
         Rojas Palacios Luis Martin
         Sanchez Alanis Jose Antonio   

Tema: Proyecto. Ejercicio 4: Algoritmo de Agrupamiento
Descripción: Clase FitnessFunction

Created on Mon Mar  7 17:14:14 2022

@author: Luis Martin R.P
"""

import numpy as np

class FitnessFunction:
    
    def __init__(self, datos, k):          # Constructor de FitnessFunction
        self.datos = datos                 # Definimos los datos (puntos)
        self.k = k                         # Definimos el numero de grupos
        self.lamda = 1                     # Definimos la variable lamda
        self.beta = 1                      # Definimos la variable beta
        
    def evaluate(self, ind, centroides):   # Metodo para evaluar un individuo y obtener su aptitud
        totalDist = 0                      # Definimos la variable totalDist
        aux = ind.genes.copy()             # Definimos un aux para manejar mejor los genes del ind

        for i in range (self.k):           # Ciclo en donde se obtienen las distancias Euclidianas de 
            grupoDist = 0                  # todos los puntos con su respectivo centroide, cada distancia se 
            for gen in aux:                # suma en totalDist y cuando se ha obtenido la suma total esta es usada
                if (gen.gen[2] == i):      # por la funcion de aptitud para obtener la apititud del individuo
                    grupoDist += np.sqrt((gen.gen[0]-centroides[i][0])**2 + (gen.gen[1]-centroides[i][1])**2)
            totalDist += grupoDist
        
        return self.beta*np.exp(-self.lamda*totalDist)  # Calculamos y retornamos la aptitud del individuo
    