#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNIVERSIDAD AUTÓNOMA DEL ESTADO DE MÉXICO
CU UAEM ZUMPANGO

UA: Algoritmos Geneticos
Profesor: Asdrubal Lopez Chau
    
Alumnos: Camacho Sandoval Brandon Ali
         Rojas Palacios Luis Martin
         Sanchez Alanis Jose Antonio   

Tema: Proyecto. Ejercicio 4: Algoritmo de Agrupamiento
Descripción: Clase AlgoritmoEvolutivo

@author: anton
Created on Mon Mar 28 12:30:20 2022
"""

import numpy as np
import random
from FitnessFunction import FitnessFunction as FF
from Poblacion import Poblacion as PB
from Seleccion import Seleccion as S
from Centroide import Centroide as C
import matplotlib.pyplot as plt


class AlgoritmoEvolutivo:

    def __init__(self, k=2, datos=[[0,0],[0,0]], size=100):   # Constructor de AlgoritmoEvolutivo
        self.k = k                                            # Definimos el numero de grupos 
        self.datos = datos.copy()                             # Definimos los datos (puntos)
        self.size = size                                      # Definimos el tamaño poblacion
        self.pob = None                                       # Definimos la poblacion 
    
    def init(self):                             # Metodo que inicializar AlgoritmoEvolutivo
        pob = PB(self.k, self.datos, self.size) # Creamos una poblacion inicial
        pob.init()                              # Inicializamos la poblacion inicial
        self.pob = pob                          # Guardamos la poblacion inicial en pob
        
        self.c = C(self.k, self.datos)          # Creamos un objeto Centroide para usar su metodos mas adelante
        self.ff = FF(self.datos, self.k)        # Creamos un objeto FitnessFunction para usar su metodos mas adelante
        self.seleccion = S()                    # Creamos un objeto Seleccion para usar su metodos mas adelante
    
    
    def showPob(self, showAptitude=False):              # Metodo para mostrar la poblacion
        pob = self.pob.poblacion                        # Definimos pob para manejar mejor los ind. de la poblacion    
        for ind in pob:                                 # Ciclo para recorrer cada individuo de la poblacion, en donde
            centros = self.c.calculaCentroide(ind)      # calculamos los centroies de cada individiuo, y los imprimimos
                                                        # al igual que su cromosoma. Ademas se agrega la posibilidad de
            if showAptitude:                            # mostrar la aptitudes del individuo, para ello se le debe de
                aptitud = self.ff.evaluate(ind,centros) # de mandar True como parametro, entonces la aptitud del
                                                        # individuo es calculada e impresa junto con los otros datos
                centros = ([ [eval("%.2f" %num) for num in centroide] for centroide in centros]) # Damos formato a los
                print("Centroides: ", centros, "  Apt. -->  ", aptitud)                          # centros para que solo
                #print(ind)                                                                      # salgan con 2 decimales                               
            else:                                                                               
                print("Centroides: ", centros)
                #print(ind)


    def GraficarMejor(self):                            # Metodo para graficar el mejor individu0
        pob = self.pob.poblacion                        # Definimos pob para manejar mejor los ind. de la poblacion 
        aptitudes = []                                  # Definimos el arreglo aptitudes
        for ind in pob:                                 # Ciclo en donde se calcula la aptitud de cada individuo de la
            centros = self.c.calculaCentroide(ind)      # poblacion y almacenada en el arreglo aptitudes
            aptitudes.append( self.ff.evaluate(ind, centros) )
            
        
        idxMejor = np.argmax(aptitudes)             # Obtengo el indice del individuo con la mejor 
                                                    # aptitud del arreglo de aptitudes
        ind = pob[idxMejor]                         # Obtengo al mejor individuo
        centroides = self.c.calculaCentroide(ind)   # Calculo los centroides del mejor individuo
        self.c.acomodargrupos(ind, centroides)      # Acomodo el grupo de los puntos de acuerdo al mejor ind.
        centroides = self.c.calculaCentroide(ind)   # Recalculo los centroides despues de acomodar los grupos
        
        print("\n-------------------------------------------")
        print("Mejor individuo:")
        centroides = ([ [eval("%.2f" %num) for num in centroide] for centroide in centroides]) # Damos formato a los
        print("Centroides: ", centroides)                                                      # centros para que solo
        print("-------------------------------------------")                                 # salgan con 2 decimales                               
        
        # Configuracion del espacio grafico
        fig= plt.figure(figsize=(11,6))              # Creamos una nueva figura y definimos su tamaño
        ax = fig.add_axes((0.05, 0.11, 0.77, 0.77) ) # Agregamos a la figura los ejes, definiendo su posicion
                                                     # y su tamaño dentro de la figura
        ax.set_title("Grupos K obtenidos")           # Establecemos el nombre el grafico
        
        for j in range (self.k):                                                            # Ciclo para graficar los
            colorAleat = "#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)]) # puntos y los centroides,   
                                                                                            # siendo de color diferente
                                                                                            # por grupo
            for punto in ind.genes:
                if punto.gen[2] == j:
                    plt.plot(punto.gen[0],punto.gen[1],     # Definimos la posicion del punto a graficar
                             marker="o",                    # Definimos el marcador con el que se graficara
                             markersize=5,                  # Definimos el tamaño del marcador
                             color=colorAleat)              # Definmos el color del marcador
            plt.plot(centroides[j][0], centroides[j][1],    # Definimos la posicion del centroide a graficar
                     marker="x",                            # Definimos el marcador con el que se graficara
                     markersize=10,                         # Definimos el tamaño del marcador
                     color = colorAleat,                    # Definmos el color del marcador
                     label='Centroide-Grupo '+str(j+1) )    # Definimos el grupo al que representa el marcador
        
        fig.legend(loc="center right",      # Definimos la posicion de la leyendas en el grafico
                   title="Grupos K",        # Definimos el titulo de las leyendas
                   frameon=False)           # Definimos que las leyendas no tendran un cuadro encerrandolas
        plt.show()                          # Mostrasmo el grafico
        
        
        

    def evolucion(self):                        # Metodo para evolucionar la poblacion
        # 1) Evaluar individuos
        # 2) Seleccionar padres para cruza
        # 3) Generar hijos (cruza)
        # 4) Mutar a algunos
        # 5) Evaluar hijos
        # 6) Seleccionar miembros de la siguiente población

        ####################################
        #####      IMPLEMENTACION      #####
        ####################################    

        if self.pob is None:                    # Condicion por si la poblacion inicial no se
            print("Inicialice la población")    # inicializo, en caso de ser cierto se manda
            return                              # se manda mensaje y se detiene la evolucion
        
        # 1) Evaluar individuos     
        pob = self.pob.poblacion                        # Definimos pob para manejar mejor los ind. de la poblacion 
        aptitudes = []                                  # Definimos el arreglo aptitudes
        for ind in pob:                                 # Ciclo en donde se calcula la aptitud de cada individuo de la
            centros = self.c.calculaCentroide(ind)      # poblacion y almacenada en el arreglo aptitudes
            aptitudes.append( self.ff.evaluate(ind, centros) )
        
        # 2) Seleccionar padres para cruza
        m = int(self.size/2)                            # Divide el tamaño de la poblacion en 2
        if m%2 == 1:                                    # Condicional por si k es impar, por lo que
            m += 1                                      # le sumamos 1 para evitar problemas en la cruza
        idx = self.seleccion.selecciona(aptitudes, m)   # Guarda m individuos seleccionados 
    
        # 3) Generar hijos (cruza)
        descendencia = []                               # Definimos el arreglo descendencia
        for i in list(range(0,m-1,2)):                  # Ciclo para recorrer la poblacion cada 2 individuos
            ip = idx[i]                                 # Selecciona el indice del padre
            im = idx[i+1]                               # Selecciona el indice de la madre
            papa = pob[ip]                              # Apartamos al padre guardadolo en una variable
            mama = pob[im]                              # Apartamos a la madre guardadola en una variable
            hijos = papa.cruza(mama)                    # Cruzamos al papa con la mama y obtenemos a los hijos
            descendencia.append(hijos[0])               # Agregamos a la descendencia el primer hijo
            descendencia.append(hijos[1])               # Agregamos a la descendencia el segundo hijo

         # 4) Mutar a algunos (5%)
        totalMutar = int(np.ceil(len(descendencia)*0.1))   # Convierte a entero un numero redondeado
                                                           # del 1 porciento del tamaño de la            
                                                           # descendencia siendo el numero obtenido
                                                           # la cantidad de individuos a mutar
        for i in range(totalMutar):                        # Ciclo para mutar individuos segun el 
                                                           # numero obtenido anteriormente, donde
            idx = random.choice(range(len(descendencia)))  # los individuos son elegidos
            descendencia[idx].mutar()                      # aleatoriamente
        
        # 5) Evaluar hijos
        for hijo in descendencia:                          # Ciclo para recorrer el arreglo descendencia y
            pob.append(hijo)                               # agregar los hijos a la poblacion
            
        aptitudes = []                                  # Definimos el arreglo aptitudes
        for ind in pob:                                 # Ciclo en donde se calcula la aptitud de cada individuo de la
            centros = self.c.calculaCentroide(ind)      # poblacion y almacenada en el arreglo aptitudes
            aptitudes.append( self.ff.evaluate(ind, centros) )
            
        # 6) Seleccionar miembros de la siguiente población
        # ELITISMO!!!!!
        idxMejor = np.argmax(aptitudes)                         # Obtiene al individuo con la mejor aptitud
        siguientePob = []                                       # Definimos el arreglo siguientePoblacion              
        siguientePob.append(pob[idxMejor])                      # Agrega al arreglo siguientePoblacion al 
                                                                # individuo con la mejor aptitud
        idx = self.seleccion.selecciona(aptitudes, self.size)   # Selecciona a los siguientes individuos
        
        for i in idx:                                           # Ciclo para reccorer a los individuos     
            siguientePob.append(pob[i])                         # seleccionados y agregarlos en el arreglo
                                                                # siguientePoblacion

        self.pob.poblacion = siguientePob                       # Guardamos al arreglo siguientePoblacion para 
                                                                # su evolución
    