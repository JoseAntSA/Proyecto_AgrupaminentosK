# -*- coding: utf-8 -*-
"""
UNIVERSIDAD AUTÓNOMA DEL ESTADO DE MÉXICO
CU UAEM ZUMPANGO

UA: Algoritmos Geneticos
Profesor: Asdrubal Lopez Chau
    
Alumnos: Camacho Sandoval Brandon Ali
         Rojas Palacios Luis Martin
         Sanchez Alanis Jose Antonio   

Tema: Proyecto. Ejercicio 4: Algoritmo de Agrupamiento
Descripción: Clase GenReal

@author: anton
Created on Mon Apr 28 11:24:09 2022
"""

class GenReal:
    
    def __init__(self, k=1, gen=[0,0]):     # Constructor de GenReal
        self.k = k                          # Define el numero de grupo del gen
        self.gen = gen.copy()               # Define el gen

    def initGen(self):                      # Metodo para inicializar el GenReal
        self.gen.append(self.k)             # Inicializa el gen agregando el grupo al que pertenece
        
    def __str__(self):                      # Metodo para imprimir el GenRel
        return str(self.gen)                # Regresa el gen como cadena